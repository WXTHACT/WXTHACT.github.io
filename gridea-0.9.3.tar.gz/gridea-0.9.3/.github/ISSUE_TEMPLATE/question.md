---
name: Question
about: 对 Gridea 有任何问题吗？
title: ''
labels: 'question'
assignees: ''

---

<!--
  如果你有任何问题也可以通过此渠道来向我们反馈。不过，通常我们建议你可以加入我们的群组获得更及时的解答。

  谢谢！
-->