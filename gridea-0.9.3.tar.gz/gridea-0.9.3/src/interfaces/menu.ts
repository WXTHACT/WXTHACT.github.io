export interface IMenu {
  name: string
  openType: string
  link: string
}
