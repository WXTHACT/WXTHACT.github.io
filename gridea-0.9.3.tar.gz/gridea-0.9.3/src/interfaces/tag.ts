export interface ITag {
  name: string
  used: boolean
  slug?: string
}
